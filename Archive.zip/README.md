# brightspacespeedgrader
Chrome Plugin to Speed Up BrightSpace Grading
